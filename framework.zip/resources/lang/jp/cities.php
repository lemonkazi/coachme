<?php
return [
    "city_info_access"=>"you don't have permission to edit",
    "name"=>[
        "required"=>"地域名を入力してください",
        "filled"=>"地域名を入力してください",
        "max"=>"名前は255文字未満にする必要があります",
    ],
    'image_path' => [
        'required' => 'アイコンを選択してください',
        'url' => '画像は有効なURLである必要があります'
    ],
];