<?php
namespace App\Helpers;

class BreadcrumbHelper
{
    static function render6()
    {
        return 'it works!';
    }
}