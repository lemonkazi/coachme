<?php $__env->startSection('title',$data['Title']); ?>
<?php $__env->startSection('content'); ?>
    <div class="program-edit">
      <form action="<?php echo e(!empty($data['program']) ? route('program-update', ['program' => $data['program']->id]): route('program-create')); ?>"
       method="POST" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>
        <div class="container">
          <?php echo e(session('msg')); ?>

          <?php if(session()->has('error')): ?>
              <div class="alert alert-danger invalid-feedback d-block"><?php echo e(session()->get('error')); ?></div>
          <?php endif; ?>
          <?php if(session('status')): ?>
            <div class="alert alert-success">
              <?php echo e(session('status')); ?>

            </div>
          <?php endif; ?>
          <?php if(session('warning')): ?>
            <div class="alert alert-warning">
              <?php echo e(session('warning')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
          <div class="row">
            <div class="col-md-6">
              <div class="row">
                <h2>Basic information</h2>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="name">Name of the program <span class="input-required">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(!empty($data['program']) ? old('name', $data['program']->name) : old('name')); ?>" required aria-describedby="nameHelp" >
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="location">Level</label>
                    <select name="level_id" id ="level_id" class="form-control" style="width: 100%">

                      <option value="">Select</option>
                      <?php $__currentLoopData = $level_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('level_id') ? old('level_id') : $data['program']->level_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <i class="bi bi-chevron-compact-down"></i>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="reg_dates">Window of registration <span class="input-required">*</span></label>
                    <div class="calender">
                      <i class="fas fa-calendar-alt"></i>
                      <input type="text" class="form-control" id="reg_dates" name="reg_dates" value="" required aria-describedby="emailHelp" >
                    </div>
                    <input type="hidden" name="reg_start_date" value="<?php echo e(!empty($data['program']) ? old('reg_start_date', $data['program']->reg_start_date) : $formatedDate); ?>">
                    <input type="hidden" name="reg_end_date" value="<?php echo e(!empty($data['program']) ? old('reg_end_date', $data['program']->reg_end_date) : $formatedDate); ?>">
                    
                    
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="Price">Price <span class="input-required">*</span></label>
                    <input type="text" class="form-control" id="Price" name="price" value="<?php echo e(!empty($data['program']) ? old('price', $data['program']->price) : old('price')); ?>" required aria-describedby="emailHelp" >
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="about">About program</label>
                    <textarea class="form-control" id="about" name ="about"><?php echo e(!empty($data['program']) ? old('about', $data['program']->about) : old('about')); ?></textarea>                   
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-3 ">
              <div class="row ">
                <h6 class="mb-3">Schedule</h6>
                <div class="col-md-12" id="coachimg-wrapper">
                  <button class="add_period form-control btn btn-primary px-3" style="width: 10px;float: left;margin-top: 10%;">+</button>
                       
                  
                    <?php 
                    if(isset($data['program_periods'])) {
                      $i=0;
                      ?>
                      <?php $__currentLoopData = $data['program_periods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php

                        $period['start_date'] = date('Y-m-d', strtotime($period['start_date']));
                        $period['end_date'] = date('Y-m-d', strtotime($period['end_date']));
                        ?>
                        <div class="form-group" id="coachimg" style="float: right;">
                          <label for="name">Period <span class="input-required">*</span></label>

                          
                         
                          <input type="text" class="form-control" id="schedule_period" value="<?php echo e($period['start_date']); ?> - <?php echo e($period['end_date']); ?>" name="schedule_period" value="" required aria-describedby="emailHelp" >
                           
                          <div class="schedule_start_date">
                            <input type="hidden" name="schedule_start_date[]" value="<?php echo e(!empty($period['start_date']) ? old('schedule_start_date', $period['start_date']) : $formatedDate); ?>">
                          </div>
                          <div class="schedule_end_date">
                          <input type="hidden" name="schedule_end_date[]" value="<?php echo e(!empty($period['end_date']) ? old('schedule_end_date', $period['end_date']) : $formatedDate); ?>">
                          </div>
                        </div>
                        <?php 
                        if ($i!=0) {
                          ?>
                          <!-- <button class="remove form-control btn btn-primary submit px-3" style="margin-top: 1%;">x</button> -->
                          <?php
                        }
                        $i++; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php
                    }
                    else {
                      ?>
                    <div class="form-group" id="coachimg" style="float: right;">
                      <label for="name">Period <span class="input-required">*</span></label>

                      <input type="text" class="form-control" id="schedule_period" name="schedule_period" value="" required aria-describedby="emailHelp" >
                      <div class="schedule_start_date">
                        <input type="hidden" name="schedule_start_date[]" value="<?php echo e(!empty($data['program']) ? old('schedule_start_date', $data['program']->schedule_start_date) : $formatedDate); ?>">
                      </div>
                      <div class="schedule_end_date">
                      <input type="hidden" name="schedule_end_date[]" value="<?php echo e(!empty($data['program']) ? old('schedule_end_date', $data['program']->schedule_end_date) : $formatedDate); ?>">
                      </div>
                    </div>
                      <?php
                    }
                    ?>

                    
                  

                </div>
                <div class="col-md-12">
                  <div class="form-group">

                    <label for="location">Location</label><span>
                      <?php $rink = ''; if (isset($_COOKIE['cookieWebURL'])) { $rink = $_COOKIE['cookieWebURL']; } ?>
                      <a href="<?php echo e($rink); ?>" target="_blank">+Add link to my Rink</a>
                    </span>
                    <select name="location_id" id ="location_id" class="form-control" style="width: 100%">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $city_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('location_id') ? old('location_id') : $data['rink']->location_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <i class="bi bi-chevron-compact-down"></i>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="dates">Starting age <span class="input-required">*</span></label>
                    <select name="starting_age" id ="starting_age" class="form-control" style="width: 100%">
                      <option value="">Select</option>
                      <?php 
                      for($value = 1; $value <= 20; $value++){ 
                        ?>
                          <option value="<?php echo e($value); ?>" <?php echo e((old('starting_age') ? old('starting_age') : $data['program']->starting_age ?? '') == $value ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                        <?php
                      }
                      ?>
                    </select>
                    <i class="bi bi-chevron-compact-down"></i>
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-3 mt-37">
              <div class="form-group">
                <label for="name">Schedule <span class="input-required">*</span></label>
                <textarea class="form-control" id="schedule_log" name ="schedule_log"><?php echo e(!empty($data['program']) ? old('schedule_log', $data['program']->schedule_log) : old('schedule_log')); ?></textarea>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="program-type">Program Type</label>
                <select name="program_type_id" id ="program_type_id" class="form-control" style="width: 100%">
                  <option value="">Select</option>
                  <?php $__currentLoopData = $program_type_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($id); ?>" <?php echo e((old('program_type_id') ? old('program_type_id') : $data['program']->program_type_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <i class="bi bi-chevron-compact-down"></i>
              </div>
            </div>
          </div>
          <div class="row">
            <h2>Contacts</h2>
            <div class="col-md-3">
              <div class="form-group">
                <label for="name">Phone <span class="input-required">*</span></label>
                <input type="text" class="form-control" id="contacts" name="contacts" value="<?php echo e(!empty($data['program']) ? old('contacts', $data['program']->contacts) : old('contacts')); ?>" required aria-describedby="emailHelp" >
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="name">WhatsApp <span class="input-required">*</span></label>
                <input type="text" class="form-control" id="whatsapp" name="whatsapp" value="<?php echo e(!empty($data['program']) ? old('whatsapp', $data['program']->whatsapp) : old('whatsapp')); ?>" required aria-describedby="emailHelp" >
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="name">Email <span class="input-required">*</span></label>
                <input type="text" class="form-control" id="email" name="email" value="<?php echo e(!empty($data['program']) ? old('email', $data['program']->email) : old('email')); ?>" required aria-describedby="emailHelp" >
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h2>Photos</h2>
              <div class="img-upload mb-4">
                <div id="image_preview">
                  <?php if(isset($data['program_photo'])): ?>
                    <?php $__currentLoopData = $data['program_photo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      
                        <img class="pic" src="<?php echo e($BASE_URL); ?>/<?php echo e($photo['path']); ?>" alt="<?php echo e($photo['name']); ?>">
                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </div>
                <input type="hidden" class="form-control" id="imagePath" name="image_path">
                <div id="aaa">    
                  <input accept="image/*" name="program_image_path[]" type='file' id="imgInp"  onchange="preview_image();" multiple/>

                  <i class="far fa-file-image"></i>
                  <i class="bi bi-plus-circle"></i>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="offset-md-8 col-md-4 mb-4">
              <div class="btn-group">
                <button type="submit" id="cancel" class="form-control btn btn-primary submit px-3">Cancel</button>
                <button type="submit" id="save" class="form-control btn btn-primary submit px-3">Save</button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>

    <script type="text/javascript">

      $(document).ready(function () {

        // add logic change value of result top condition
        $('#province_id').on('change', function(){
            var name = $(this).attr('name');
            $('#city_id').html('');
            if (name == '') {
                return false;
            }

            var value = $(this).val();
            var csrfToken = $('meta[name="_token"]').attr('content') ? $('meta[name="_token"]').attr('content') : '';
          

            var data = {
                province_id: value,
                _token:csrfToken
            };


            $.ajax({
              type: 'POST',
              url: baseUrl + '/ajax_citylist',
              data: data,
              //dataType: 'json',
              success: function (response) {
                console.log(response);
                if (response) {
                    $('#city_id').html(response);
                } else {
                    $('#city_id').html('');
                }
              },
              complete: function () {}
            });
            return false;
        });
      });
    </script>
    
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/resources/views/pages/program/edit.blade.php ENDPATH**/ ?>