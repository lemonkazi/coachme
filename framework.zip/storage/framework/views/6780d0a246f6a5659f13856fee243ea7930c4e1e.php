<?php $__env->startSection('title',$data['Title']); ?>
<?php $__env->startSection('content'); ?>
    <div class="program-list coach-list">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
                <div class=" text-white">        
                  <div class="card-body">
                    <div class="row">
                      <h1>
                        Filters                    
                      </h1>
                      <label for="">Speciality</label>
                      <div class="check-section">
                        <?php $__currentLoopData = $speciality_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="speciality" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((old('speciality_id') ? old('speciality_id') : $_GET['speciality_id'] ?? '') == $id ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </div>
                      <label for="">Coaching certificate</label>
                      <div class="check-section">
                        <?php $__currentLoopData = $certificate_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="certificate_id" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((old('certificate_id') ? old('certificate_id') : $_GET['certificate_id'] ?? '') == $id ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Location <span class="input-required">*</span></label>
                        <select name="province_id" id ="province_id" class="location form-control listdates">
                          <option value="">Select</option>
                          <?php $__currentLoopData = $province_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($id); ?>" <?php echo e((old('province_id') ? old('province_id') : $_GET['province_id'] ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-chevron-compact-down"></i>
                      </div>
                      <div class="form-group position-relative without-label">
                        <select name="location_id" id ="city_id" class="form-control location listdates">
                          <option value="">Select</option>
                          <?php $__currentLoopData = $city_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((old('location_id') ? old('location_id') : $_GET['location_id'] ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-chevron-compact-down"></i>
                      </div>
                      
                      <label for="">Price</label>
                      <div class="check-section">

                        <?php $__currentLoopData = $price_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="price_id" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((old('price_id') ? old('price_id') : $_GET['price_id'] ?? '') == $id ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Rinks <span class="input-required">*</span></label>
                        <select class="form-control location" id="rinks" name="rink" multiple="multiple">
                          <?php $__currentLoopData = $rink_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php $__currentLoopData = $filtered_rink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aItemKey => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($id == $p): ?>selected="selected"<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($value); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-plus-lg"></i>
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Language <span class="input-required">*</span></label>
                        <select class="form-control listdates location" id="campdates" name="language" multiple="multiple">
                          <?php $__currentLoopData = $language_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php $__currentLoopData = $filtered_language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aItemKey => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($id == $p): ?>selected="selected"<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($value); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-plus-lg"></i>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-md-8">
              <div class="row">

                  <?php if(isset($data['coaches'])): ?>
                    <?php $__currentLoopData = $data['coaches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <div class="col-sm-4 mb-2">
                        <div class="card profile">           
                            <div class="card-body">
                              <div class="row">
                                <div class="col-md-12">
                                  <?php if(!empty($coach['avatar_image_path'])): ?>         
                                    <img src="<?php echo e($BASE_URL); ?>/photo/user_photo/<?php echo e($coach['avatar_image_path']); ?>" />      
                                  <?php else: ?>
                                    <img src="https://via.placeholder.com/150x150" alt="">        
                                  <?php endif; ?>
                                  
                                </div>
                                <div class="col-md-12">
                                  <h3><?php echo e($coach['name']); ?> <?php echo e($coach['family_name']); ?></h3>
                                  <h4><?php echo e($coach['city_name']); ?>, <?php echo e($coach['province_name']); ?></h4>
                                </div> 
                                <div class="col-md-12 learn-more">
                                  <a href="<?php echo e(!empty($coach['id']) ? route('coach-details', ['user' => $coach['id']]): ''); ?>" class="btn btn-custom mb-2 green">Learn more</a>
                                </div>
                                
                              </div>
                            </div>
                        </div>
                      </div>
                     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
                
             
              </div>
            </div>
          </div>
        </div>
    </div>

    <script type="text/javascript">

      $(document).ready(function () {
        $("#ex2").bootstrapSlider({});
        // add logic change value of result top condition
        $('#province_id').on('change', function(){
            var name = $(this).attr('name');
            $('#city_id').html('');
            if (name == '') {
                return false;
            }

            var value = $(this).val();
            var csrfToken = $('meta[name="_token"]').attr('content') ? $('meta[name="_token"]').attr('content') : '';
          

            var data = {
                province_id: value,
                _token:csrfToken
            };


            $.ajax({
              type: 'POST',
              url: baseUrl + '/ajax_citylist',
              data: data,
              //dataType: 'json',
              success: function (response) {
                console.log(response);
                if (response) {
                    $('#city_id').html(response);
                } else {
                    $('#city_id').html('');
                }
              },
              complete: function () {}
            });
            return false;
        });
      });
    </script>
    
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/resources/views/pages/coach/list.blade.php ENDPATH**/ ?>