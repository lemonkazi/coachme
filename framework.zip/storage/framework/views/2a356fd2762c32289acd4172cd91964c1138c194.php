<?php echo e($slot); ?>

<?php /**PATH /home/ziih7ldwv5wz/public_html/framework/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>