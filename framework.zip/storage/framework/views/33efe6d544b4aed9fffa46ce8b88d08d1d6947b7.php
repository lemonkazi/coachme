<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
      <!-- MOdal Start-->
      <section class="modal-section">
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content registration-modal">
              <div class="modal-body p-4 p-md-5 ">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="text-center mb-2">Log in</h3>
                <h5 class="mb-3">Welcome back to Coach me solutions!</h5>
                <div class="alert alert-danger login" style="display:none"></div>
                <form method="POST" action="<?php echo e(url('user/login')); ?>" class="login-form">
                  <?php echo csrf_field(); ?>
                  <?php if(session()->has('error')): ?>
                      <div class="alert alert-danger invalid-feedback d-block"><?php echo e(session()->get('error')); ?></div>
                  <?php endif; ?>
                  <?php if(session('status')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                    </div>
                  <?php endif; ?>
                  <?php if(session('warning')): ?>
                    <div class="alert alert-warning">
                      <?php echo e(session('warning')); ?>

                    </div>
                  <?php endif; ?>
                  <div class="form-group">
                    <label for="log-email">Email</label>
                    <input id="email" type="email" class="form-control rounded-left <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="email" id="log-email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group">
                    <label for="log-password">Password</label>
                    <div class="icon-input mb-3">
                      <input id="password" type="password" class="form-control rounded-left <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" id="log-password" name="password" required autocomplete="password">
                      <i class="bi bi-eye-slash-fill"></i>
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                  <div class="form-group">
                    <button type="submit" id="userLogin" class="form-control btn btn-primary submit px-3">Login</button>
                  </div>
                </form>
                <h1 class="a">or</h1>
                <h3 class="text-center mb-2">Sign up</h3>
                <h5 class="mb-3">Sign up to join Coach me solutions!</h5>
                <div class="alert alert-danger registration" style="display:none"></div>
                <div class="alert alert-success registration" style="display:none"></div>
                <form method="POST" action="<?php echo e(url('user/register')); ?>" class="registration-form">
                  <?php echo csrf_field(); ?>
                  <?php if(session()->has('error')): ?>
                      <div class="alert alert-danger invalid-feedback d-block"><?php echo e(session()->get('error')); ?></div>
                  <?php endif; ?>
                  <?php if(session('status')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                    </div>
                  <?php endif; ?>
                  <?php if(session('warning')): ?>
                    <div class="alert alert-warning">
                      <?php echo e(session('warning')); ?>

                    </div>
                  <?php endif; ?>
                  <div class="form-group">
                    <label for="sign-email">Email</label>
                    <input type="text" class="form-control rounded-left <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="email" id="sign-email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group">
                    <label for="userSelect">Type of user</label>
                    <select class="form-control" name="authority" id="userSelect">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $authority; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($id); ?>" <?php echo e((old('authority') ? old('authority') : $data['user']->authority ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="reg-password">Password</label>
                    <div class="icon-input mb-3">
                      <input type="password" class="form-control rounded-left <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="at least 8 symbols" name="password" id="reg-password" required autocomplete="new-password">
                      <i class="bi bi-eye-slash-fill"></i>
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                  <div class="form-group">
                    <button type="submit" class="form-control btn btn-primary submit px-3" id="userRegister">Sign Up</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /modal-->
      <?php if(session()->has('error')): ?>
          <div class="alert alert-danger invalid-feedback d-block"><?php echo e(session()->get('error')); ?></div>
      <?php endif; ?>
      <?php if(session('status')): ?>
        <div class="alert alert-success">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>
      <?php if(session('warning')): ?>
        <div class="alert alert-warning">
          <?php echo e(session('warning')); ?>

        </div>
      <?php endif; ?>
      <!-- /hero section start -->
    <section class="hero-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="text-content">
                        <h1>Finding <span>a coach, a program or camp</span> has never been that simple.</h1>
                        <p>Coach me solutions is the easiest, safest and most affordable way to connect with an experienced coach who can help you improve your athletic performance and reach your individual goals.</p>

                        <button type="button" class="btn hero-button">Explore  <i class="fas fa-arrow-right"></i></button>
                    </div>
                </div>
                <div class="col-md-5">
                <div class="hero-image">
                    <img src="<?php echo e(asset('img/top-img.png')); ?>" alt="">
                </div>
                </div>
            </div>
        </div>
    </section>
    <section class="drop-arrow">
      <i class="fas fa-angle-down"></i>
    </section>
    
    <!-- /card section -->
    <section class="card-section">
      <div class="content">

        <h1>Steps For Your Great Sports Experience</h1>
        <p>Connecting you to professionally trained coaches, is what we strive to do.</p>
        </div>

        <div class="container">
          <div class="row">
            <div class="col-sm-4">
              <div class="card text-white card-has-bg click-col">        
                <div class="card-img-overlay d-flex flex-column">
                  <div class="card-body">
                    <h4 class="card-title mt-0 ">
                      <a herf="#">Step 1</a>
                    </h4>
                    <img class="card-img" src="<?php echo e(asset('img/purpose.png')); ?>" alt="">
                  </div>
                  <div class="card-footer">
                    <div class="media">
                      <div class="media-body">
                        <h6 class="my-0 d-block">
                          Go on the coach, camp 
                          or program tab and look for what you need
                        </h6>     
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-sm-4"><div class="card text-white card-has-bg click-col">        
              <div class="card-img-overlay d-flex flex-column">
               <div class="card-body">
                  <h4 class="card-title mt-0 "><a herf="#">Step 2</a></h4>
                 <img class="card-img" src="<?php echo e(asset('img/tutorial.png')); ?>" alt="">
                </div>
                <div class="card-footer">
                 <div class="media">
           <div class="media-body">
          <h6 class="my-0 d-block">
            Click on the coach, the program or the camp to know more
          </h6>     
        </div>
      </div>
                </div>
              </div>
            </div></div>


            <div class="col-sm-4"><div class="card text-white card-has-bg click-col">        
              <div class="card-img-overlay d-flex flex-column">
               <div class="card-body">
                  <h4 class="card-title mt-0 "><a herf="#">Step 3</a></h4>
                 <img class="card-img" src="<?php echo e(asset('img/trust.png')); ?>" alt="">
                </div>
                <div class="card-footer">
                 <div class="media">
           <div class="media-body">
          <h6 class="my-0 d-block">
            Choose the best way for you to contact them
          </h6>     
        </div>
      </div>
                </div>
              </div>
            </div></div>
        
      </div>
        
      </div>
      </section>
      <section class="drop-arrow">
        <i class="fas fa-angle-down"></i>
      </section>
      <!-- /carosel section -->
      <section class="carousel-section">
        <h1>Here's what famous coaches say
          about Coach Me Solution...</h1>

          <div class="wrap">  
            <div class="slider">
              

              <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                

                <div class="item">
                  <div class="card card_red text-center">
                    <div class="title">

                      <img class="pic" src="<?php echo e($BASE_URL); ?>/photo/testimonial_photo/<?php echo e($testimonial->image_path); ?>" alt="PAT">
                      <h2><?php echo e($testimonial->name); ?></h2>
                    </div>
                    <p>"<?php echo nl2br(e($testimonial->comment)); ?>"</p>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              
              
              
            </div>
          </div>
      </section>
      <section class="drop-arrow">
        <i class="fas fa-angle-down"></i>
      </section>
      <section class="map-section">
        <div class="container">
          <div class="col-md-12 ">
            <div class="card p-3">
              <div class="row">
              <div class="col-md-8">
                <div class="title">
                  <h2>Find Rinks A Rinks Around You</h2>
                  
                  <div class="search-div mb-2">
                    <button type="button" class="btn green-btn">Use my location</button>
                    <input type="text" placeholder="Search" class="search-btn"><i class="bi bi-search"></i>
                  </div>
                </div>
                <div class="polaroid">                 
                    <div id="map"></div>                 
                </div>
              </div>
              <div class="col-md-4">
                <div class="address-group">
                  <div class="address">
                    <div class="number">
                      <img src="<?php echo e(asset('img/Ellipse 17.png')); ?>" alt="" srcset="">
                      <span>1</span>
                    </div>
                    <div class="description">
                      <h5>Kitsilano FSC</h5>
                      <a href="">info@kitsfsc.ca</a>
                      <p>
                        2690 Larch Street Vancouver, BC V6K4K9 604-737-6000
                      </p>
                      <a href="">www.kitsfsc.ca</a>
                      <h6>3,79 kilometers</h6>
                      <p class="gray">Directions</p>
                    </div>
                  </div>
                  <div class="address">
                    <div class="number">
                      <img src="<?php echo e(asset('img/Ellipse 17.png')); ?>" alt="" srcset="">
                      <span>2</span>
                    </div>
                    <div class="description">
                      <h5>Kitsilano FSC</h5>
                      <a href="">info@kitsfsc.ca</a>
                      <p>
                        2690 Larch Street Vancouver, BC V6K4K9 604-737-6000
                      </p>
                      <a href="">www.kitsfsc.ca</a>
                      <h6>3,79 kilometers</h6>
                      <p class="gray">Directions</p>
                    </div>
                  </div>
                  <div class="address">
                    <div class="number">
                      <img src="<?php echo e(asset('img/Ellipse 17.png')); ?>" alt="" srcset="">
                      <span>3</span>
                    </div>
                    <div class="description">
                      <h5>Kitsilano FSC</h5>
                      <a href="">info@kitsfsc.ca</a>
                      <p>
                        2690 Larch Street Vancouver, BC V6K4K9 604-737-6000
                      </p>
                      <a href="">www.kitsfsc.ca</a>
                      <h6>3,79 kilometers</h6>
                      <p class="gray">Directions</p>
                    </div>
                  </div>
                  
                </div>
              </div>
              </div>
                <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAl_3j4BivMuCGpS5DS73Rkt7SNvy29eBQ&callback=initMap" async defer></script>
            </div>
          </div>
        </div>
      </section>

    
      <!-- footer section -->
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aburayhan/public_html/coach-me/resources/views/pages/home.blade.php ENDPATH**/ ?>