<?php $__env->startSection('title',$data['Title']); ?>
<?php $__env->startSection('content'); ?>
    <div class="rink-list">
        <div class="container">
          <div class="row">
            <div class="col-md-10">
              <h2>Rink basic information</h2>
              <form action="<?php echo e(route('rink-list')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo e(session('msg')); ?>

                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger invalid-feedback d-block"><?php echo e(session()->get('error')); ?></div>
                <?php endif; ?>
                <?php if(session('status')): ?>
                  <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                  </div>
                <?php endif; ?>
                <?php if(session('warning')): ?>
                  <div class="alert alert-warning">
                    <?php echo e(session('warning')); ?>

                  </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                  <div class="alert alert-danger">
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="location">Select your rink</label>
                      <select name="cookieRink" id="set_rink_id" class="set_cookie form-control" style="width: 100%">
                        <option value="">Select</option>

                        <?php $__currentLoopData = $rink_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((old('cookieRink') ? old('cookieRink') : $data['rink']->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <i class="bi bi-chevron-compact-down"></i>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="location">Website link</label>
                      <input type="text" class="form-control set_cookie" id="set_web_site_url" name="cookieWebURL" value="<?php echo e(!empty($data['user']) ? old('cookieWebURL', $data['user']->web_site_url) : old('cookieWebURL')); ?>" required aria-describedby="emailHelp" >
                    </div>
                  </div>

                  <div class="col-md-4 mt-4">
                    <div class="btn-group">
                      <!-- <button type="submit" id="cancel" class="form-control btn btn-primary submit px-3">Cancel</button> -->
                      <button type="submit" id="save" class="form-control btn btn-primary submit px-3">Save</button>
                    </div>
                  </div>
                </div>
              </form>
              
              <a href="<?php echo e(route('camp-create')); ?>" class="btn btn-custom mb-2 green col-md-3 w-60">Create a camp</a><br/>
              <a href="<?php echo e(route('program-create')); ?>" class="btn btn-custom mb-4 blue col-md-3 w-60">Create a program</a>
              <div class="row">
                <?php if(isset($data['programs'])): ?>
                <div class="col-md-12">
                  <h2>Your Programs</h2>
                  <div class="row">
                  <div class="col-sm-12">
                    <?php if(isset($data['programs'])): ?>
                      <?php $__currentLoopData = $data['programs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card text-white card-has-bg click-col mb-4">        
                          <div class="card-img-overlay d-flex flex-column">
                            <div class="card-body">
                              <div class="row">
                                <div class="col-md-3">
                                  <?php if(isset($program['program_photo'][0])){ ?>
                                    <img src="<?php echo e($BASE_URL); ?>/<?php echo e($program['program_photo'][0]['path']); ?>" alt="">
                                  <?php } else{ ?>
                                    <img src="<?php echo e(asset('img/default-thumbnail.jpeg')); ?>" alt="">
                                  <?php } ?> 
                                </div>
                                
                                <div class="col-md-6">
                                  <h3><?php echo e($program['name']); ?></h3>
                                  <?php 
                                  if(isset($program['program_period'])) {
                                    
                                    if(count($program['program_period']) >1) {
                                      $i=0;
                                      ?>
                                      <h6>
                                        <?php $__currentLoopData = $program['program_period']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                          <?php
                                            $period['start_date'] = date('F', strtotime($period['start_date']));
                                            $period['end_date'] = date('F', strtotime($period['end_date']));
                                          ?>
                                          <?php echo e(ucwords(strtolower($period['type']))); ?> (<?php echo e($period['start_date']); ?> - <?php echo e($period['end_date']); ?>)

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </h6> 
                                      <?php
                                    }
                                    else {

                                      //$today = new DateTime();
                                      $today      = strtotime('today');
                                      $date_year = date('Y', $today);

                                      $start_date      = strtotime($program['program_period'][0]['start_date']);
                                      $start_year = date('Y', $start_date);
                                      if ($date_year == $start_year) {
                                        $start_date = date('F d', $start_date);
                                      } else {
                                        $start_date = date('F d, Y', $start_date);
                                      }
                                      

                                      $end_date      = strtotime($program['program_period'][0]['end_date']);
                                      $end_year = date('Y', $end_date);
                                      if ($date_year == $end_year) {
                                        $end_date = date('F d', $end_date);
                                      } else {
                                        $end_date = date('F d, Y', $end_date);
                                      }
                                      ?>
                                      <h6><?php echo e($start_date); ?>-<?php echo e($end_date); ?></h6>
                                      <?php
                                    }
                                  }
                                  ?>
                                  <?php if(isset($program['rink'])): ?>
                                    <h5><i class="fas fa-map-marker-alt"></i><?php echo e($program['rink']['address']); ?></h5>
                                  <?php endif; ?>
                                  
                                  <h5><i class="fas fa-clock"></i>Starting at <?php echo e($program['starting_age']); ?></h5>
                                  <h5><i class="fas fa-road"></i><?php echo e($program['level_name']); ?></h5>
                                </div> 
                                <div class="col-md-3 learn-more">
                                  <a href="<?php echo e(!empty($program['id']) ? route('program-details', ['program' => $program['id']]): ''); ?>" class="btn btn-primary">
                                    <i class="fas fa-eye"></i>
                                  </a>
                                  <a href="<?php echo e(!empty($program['id']) ? route('program-update', ['program' => $program['id']]): ''); ?>" class="btn btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                  </a> 
                                  <a href="javascript:;" data-id="<?php echo e($program['id']); ?>" class="btn btn-danger btn_delete_program" data-toggle="tooltip" title="Delete">
                                    <i class="fa fa-trash" aria-hidden="true"></i>   
                                  </a> 

                                </div>
                                
                              </div>
                            </div>
                            
                          </div>
                        </div>
                       
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                  </div>
                  </div>
                </div>
                <?php endif; ?>
              </div>

              <div class="row">
                <?php if(isset($data['camps'])): ?>
                <div class="col-md-12">
                  <h2>Your Camps</h2>
                  <div class="row">
                  <div class="col-sm-12">
                    <?php if(isset($data['camps'])): ?>
                      <?php $__currentLoopData = $data['camps']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card text-white card-has-bg click-col mb-4">        
                          <div class="card-img-overlay d-flex flex-column">
                            <div class="card-body">
                              <div class="row">
                                <div class="col-md-3">
                                  <?php if(isset($camp['camp_photo'][0])){ ?>
                                    <img src="<?php echo e($BASE_URL); ?>/<?php echo e($camp['camp_photo'][0]['path']); ?>" alt="">
                                  <?php } else{ ?>
                                    <img src="<?php echo e(asset('img/default-thumbnail.jpeg')); ?>" alt="">
                                  <?php } ?>  
                                </div>
                                
                                <?php

                                //$today = new DateTime();
                                $today      = strtotime('today');
                                $date_year = date('Y', $today);

                                $start_date      = strtotime($camp['start_date']);
                                $start_year = date('Y', $start_date);
                                if ($date_year == $start_year) {
                                  $start_date = date('F d', $start_date);
                                } else {
                                  $start_date = date('F d, Y', $start_date);
                                }
                                

                                $end_date      = strtotime($camp['end_date']);
                                $end_year = date('Y', $end_date);
                                if ($date_year == $end_year) {
                                  $end_date = date('F d', $end_date);
                                } else {
                                  $end_date = date('F d, Y', $end_date);
                                }
                                ?>
                                <div class="col-md-6">
                                  <h3><?php echo e($camp['name']); ?></h3>
                                  <h6><?php echo e($start_date); ?>-<?php echo e($end_date); ?></h6>
                                  <?php if(isset($camp['rink'])): ?>
                                    <h5><i class="fas fa-map-marker-alt"></i>
                                      
                                        <?php echo e($camp['rink']['address']); ?>

                                      
                                    </h5>
                                  <?php endif; ?>
                                  
                                  
                                  <?php if(isset($data['camp_type_name']) && !empty($data['camp_type_name'])): ?>
                                    <?php $__currentLoopData = $data['camp_type_name']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <h5><i class="fas fa-clock"></i><?php echo e($camp_type['name']); ?></h5>

                                       
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                                  <h5><i class="fas fa-road"></i><?php echo e($camp['level_name']); ?></h5>
                                </div> 
                                <div class="col-md-3 learn-more">
                                  <a href="<?php echo e(!empty($camp['id']) ? route('camp-details', ['camp' => $camp['id']]): ''); ?>" class="btn btn-primary">
                                    <i class="fas fa-eye"></i>
                                  </a>
                                  <a href="<?php echo e(!empty($camp['id']) ? route('camp-update', ['camp' => $camp['id']]): ''); ?>" class="btn btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                  </a> 
                                  <a href="javascript:;" data-id="<?php echo e($camp['id']); ?>" class="btn btn-danger btn_delete_camp" data-toggle="tooltip" title="Delete">
                                    <i class="fa fa-trash" aria-hidden="true"></i>   
                                  </a> 
                                </div>
                                
                              </div>
                            </div>
                            
                          </div>
                        </div>
                       
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                  </div>
                  </div>
                </div>
                <?php endif; ?>
              </div>
            </div>
          </div>

        </div>
    </div>

    <script type="text/javascript">

      $(document).ready(function () {

        // add logic change value of result top condition
        $('.set_cookie').on('change', function(){
            var name = $(this).attr('name');
            if (name == '') {
                return false;
            }

            var value = $(this).val();
            var csrfToken = $('meta[name="_token"]').attr('content') ? $('meta[name="_token"]').attr('content') : '';

            var data = {
                value: value,
                cookieName: name,
                _token:csrfToken
            };
            $.ajax({
              type: 'POST',
              url: baseUrl + '/ajax_set_cookie',
              data: data,
              //dataType: 'json',
              success: function (response) {
                console.log(response);
                // if (response) {
                //     $('#city_id').html(response);
                // } else {
                //     $('#city_id').html('');
                // }
              },
              complete: function () {}
            });
            return false;
        });



       
      });
    </script>
    
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aburayhan/coach.abu-rayhan.me/framework/resources/views/pages/rink/list.blade.php ENDPATH**/ ?>