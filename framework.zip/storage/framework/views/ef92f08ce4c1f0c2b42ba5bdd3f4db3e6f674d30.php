[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>