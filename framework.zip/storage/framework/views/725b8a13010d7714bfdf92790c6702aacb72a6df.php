<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>