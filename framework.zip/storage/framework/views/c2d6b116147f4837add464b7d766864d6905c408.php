<div class="modal" id="modal_alert">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo __('LABEL_INFO') ?></h4>
            </div>
            <div class="modal-body">
                <p id="modal_alert_body"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal"><?php echo __('LABEL_CLOSE') ?></button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/coachme/resources/views/layouts/elements/modal_alert.blade.php ENDPATH**/ ?>