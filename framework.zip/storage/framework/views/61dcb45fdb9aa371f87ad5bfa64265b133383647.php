<?php echo e($slot); ?>

<?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>