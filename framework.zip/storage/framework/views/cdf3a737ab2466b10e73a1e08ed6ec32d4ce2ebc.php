<?php $__env->startSection('title',$data['Title']); ?>
<?php $__env->startSection('content'); ?>
    <div class="program-list camp-list">
        <div class="container">
          <div class="row">
            <div class="col-md-12  d-flex justify-content-between">
              <button class="btn btn-custom text-white openTab sp"> Filter</button>
              <a href="<?php echo e(url('/camp/list')); ?>" class="btn btn-custom mb-2 green sp">View List</a>  
            </div>
            <div class="col-md-4 filter">
                <div class=" text-white">        
                  <div class="card-body">
                    <div class="row">
                      <h1>
                        Filters  <i class="bi bi-x sp"></i>
                        <a href="<?php echo e(url('/camp/list')); ?>" class="btn btn-custom mb-2 green pc">View List</a>                
                      </h1>
                      <label for="">Type of Camp</label>
                      <div class="check-section">
                        <?php
                        $campArray = array();
                        if (isset($_GET['camp_type_id'])) {
                          $campArray = explode(',', $_GET['camp_type_id']);
                        }
                        
                        ?>

                        <?php $__currentLoopData = $camp_type_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="camp_type_id" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((in_array($id, $campArray)) ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <label for="">Levels</label>
                      <div class="check-section">
                        <?php
                        $levelArray = array();
                        if (isset($_GET['level_id'])) {
                          $levelArray = explode(',', $_GET['level_id']);
                        }
                        
                        ?>

                        <?php $__currentLoopData = $level_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="level_id" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((in_array($id, $levelArray)) ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Location <span class="input-required">*</span></label>        
                        <select name="province_id" id ="province_id" class="location form-control listdates">
                          <option value="">Select</option>
                          <?php $__currentLoopData = $province_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($id); ?>" <?php echo e((old('province_id') ? old('province_id') : $_GET['province_id'] ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-chevron-compact-down"></i>
                      </div>
                      <div class="form-group position-relative without-label">                        
                        <select name="location_id" id ="city_id" class="form-control location listdates">
                          <option value="">Select</option>
                          <?php $__currentLoopData = $city_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((old('location_id') ? old('location_id') : $_GET['location_id'] ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-chevron-compact-down"></i>
                      </div>
                      <div class="form-group range">
                        <label for="">Price Range</label>
                        <?php 
                        $min = 0;
                        $max = $maxPrice;
                        if (isset($_GET['min']) && !empty($_GET['min'])) {
                          $min = $_GET['min'];
                        }
                        if (isset($_GET['max']) && !empty($_GET['max'])) {
                          $max = $_GET['max'];
                        }
                        ?>
                        <div>
                          <span class="minVal">$<?php echo e($min); ?></span>
                          <span class="maxVal">$<?php echo e($max); ?></span>
                        </div>
                          <input id="ex2" type="text" class="span2" value="" data-slider-min="0" data-slider-max="<?php echo e($maxPrice); ?>" data-slider-step="5" data-slider-value="[<?php echo e($min); ?>,<?php echo e($max); ?>]"/>
                        <div>
                          <span>min</span>
                          <span>max</span>
                        </div>
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Coach <span class="input-required">*</span></label>
                        <select class="form-control listdates location" id="coach" name="coach_id" multiple="multiple">
                          <?php if(isset($data['coaches'])): ?>
                            <?php $__currentLoopData = $data['coaches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($id); ?>" <?php $__currentLoopData = $filtered_coach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aItemKey => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($id == $p): ?>selected="selected"<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($value); ?></option>
                          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </select>
                        <i class="bi bi-plus-lg"></i>
                      </div>
                      <label for="">Duration</label>
                      <div class="check-section">

                        <?php
                        $duration = [
                                'day_0-3'    => '1-3 days',
                                'day_4-7'    => '4-7 days',
                                'day_8-21'      => '1-3 weeks',
                                'day_22-100'    => '4* weeks'
                            ];
                        $myArray = array();
                        if (isset($_GET['duration'])) {
                          $myArray = explode(',', $_GET['duration']);
                        }
                        
                        ?>
                        <?php foreach ($duration as $id => $value): ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="duration" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((in_array($id, $myArray)) ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach ?>
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Date <span class="input-required">*</span></label>
                        <select class="form-control listdates location" id="campdates" name="month" multiple="multiple">
                          
                          <?php
                          foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $new_i => $date_str) {
                              
                              $new_i = $new_i+1; 
                              ?>
                              <option value="<?php echo e($new_i); ?>" <?php $__currentLoopData = $filtered_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aItemKey => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($new_i == $p): ?>selected="selected"<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($date_str); ?></option>
                            <?php
                          }
                          ?>
                        </select>
                        <i class="bi bi-plus-lg"></i>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-md-8">
              <div class="row">
              <div class="col-sm-12">
                <div class="card card-has-bg click-col">           
                    <div class="card-body">
                      <div class="row">
                        <div class="col-md-12">
                          <div id='calendar'></div>
                        </div>
                        <div class="events sp">
                          <?php
                          $backgroundColor = array(
                            0=>'#A7DAE9',
                            1=>'#D0E6A5',
                            2=>'#D1B3DD'
                          );
                          $response = '';
                          foreach ($current_camps as $key => $value) {

                          
                            // It returns array of random keys
                            //$key = array_rand( $backgroundColor);
                            $value['start_date'] = strtotime($value['start_date']);
                            $value['start_date'] = date( 'M d', $value['start_date']);

                            $value['end_date'] = strtotime($value['end_date']);
                            $value['end_date'] = date( 'M d', $value['end_date']);

                            if (isset($backgroundColor[$key])) {
                              $backgroundColor[$key] = $backgroundColor[$key];
                            } else {
                              $backgroundColor[$key] = '#A7DAE9';
                            }

                            $response .= '<div class="event" style="background-color:'.$backgroundColor[$key].'">';
                            $response .= '<h4>'.$value['name'].'</h4>';
                            $response .= '<p>'.$value['start_date'].' - '.$value['end_date'].'</p>';
                            $response .= '</div>';
                          }
                          echo $response;
                          ?>
                          <!-- <div class="event">
                            <h4>Annecy club summer camp</h4>
                            <p>May 1 - May 15</p>
                          </div> -->
                        </div>
                      </div>
                    </div>
                </div>
                <div class="col-md-12 sp">
                  
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        console.log('<?php echo json_encode($camps) ?>');
        var calendar = new FullCalendar.Calendar(calendarEl, {
          plugins: [ 'dayGrid','moment','interaction' ],
          header: { center: 'prev,title,next,agendaWeek', left: '',right:'' },
          //link https://fullcalendar.io/docs/v4/dateClick
          dateClick: function(info) {          
            console.log(info.date.toISOString());
            console.log(info.dateStr);
            console.log(info.allDay);
            console.log(info.dayEl);
            console.log(info.jsEvent);

            var date = info.dateStr;
            $('.events').html('');
            if (date == '') {
                return false;
            }

            //var value = $(this).val();
            var csrfToken = $('meta[name="_token"]').attr('content') ? $('meta[name="_token"]').attr('content') : '';
          

            var data = {
                date: date,
                _token:csrfToken,
                params:<?php echo json_encode($params) ?>
            };


            $.ajax({
              type: 'POST',
              url: baseUrl + '/ajax_get_camp',
              data: data,
              //dataType: 'json',
              success: function (response) {
                console.log(response);
                if (response) {
                    $('.events').html(response);
                } else {
                    $('.events').html('');
                }
              },
              complete: function () {}
            });
            //return false;
            //$('.event').show();
          },
          events : <?php echo json_encode($camps) ?>
          
        });

        calendar.render();
      });
    </script>
    <script type="text/javascript">

      $(document).ready(function () {
        
        console.log($('.min-slider-handle').attr('aria-valuenow'));
        $('.min-slider-handle').on('change',function(){
          console.log($(this).attr('aria-valuenow'))
        })
        // add logic change value of result top condition
        $('#province_id').on('change', function(){
            var name = $(this).attr('name');
            $('#city_id').html('');
            if (name == '') {
                return false;
            }

            var value = $(this).val();
            var csrfToken = $('meta[name="_token"]').attr('content') ? $('meta[name="_token"]').attr('content') : '';
          

            var data = {
                province_id: value,
                _token:csrfToken
            };


            $.ajax({
              type: 'POST',
              url: baseUrl + '/ajax_citylist',
              data: data,
              //dataType: 'json',
              success: function (response) {
                console.log(response);
                if (response) {
                    $('#city_id').html(response);
                } else {
                    $('#city_id').html('');
                }
              },
              complete: function () {}
            });
            return false;
        });

        $('.openTab').on('click',function (e) {
          e.preventDefault();
          $('.filter').show();

        })
        $('h1 i').on('click',function(e) {
          e.preventDefault();
          $('.filter').hide();
        })
      });

     

    </script>
    
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziih7ldwv5wz/public_html/framework/resources/views/pages/camp/filter.blade.php ENDPATH**/ ?>