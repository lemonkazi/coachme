<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/ziih7ldwv5wz/public_html/framework/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>