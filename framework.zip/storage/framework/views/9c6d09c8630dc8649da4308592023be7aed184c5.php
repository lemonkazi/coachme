<?php $__env->startSection('title',$data['Title']); ?>
<?php $__env->startSection('content'); ?>
    <div class="program-list">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <button class="sp btn btn-custom text-white openTab"> Filter</button>
            </div>
            <div class="col-md-4 filter">
                <div class=" text-white">        
                  <div class="card-body">
                    <div class="row">
                      <h1>
                        Filters <i class="bi bi-x sp"></i>                   
                      </h1>
                      <label for="">Type of program <i class="fas fa-info-circle"></i></label>
                      <div class="check-section">
                        <?php
                        $programArray = array();
                        if (isset($_GET['program_type_id'])) {
                          $programArray = explode(',', $_GET['program_type_id']);
                        }
                        
                        ?>
                        <?php $__currentLoopData = $program_type_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="program_type_id" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((in_array($id, $programArray)) ? 'checked="checked"' : ''); ?>  >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </div>
                      <label for="">Levels</label>
                      <div class="check-section">
                        <?php
                        $levelArray = array();
                        if (isset($_GET['level_id'])) {
                          $levelArray = explode(',', $_GET['level_id']);
                        }
                        
                        ?>
                        <?php $__currentLoopData = $level_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="level_id" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((in_array($id, $levelArray)) ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Location <span class="input-required">*</span></label>
                        
                        <select name="province_id" id ="province_id" class="location form-control">
                          <option value="">Select</option>
                          <?php $__currentLoopData = $province_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($id); ?>" <?php echo e((old('province_id') ? old('province_id') : $_GET['province_id'] ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-chevron-compact-down"></i>
                      </div>
                      <div class="form-group position-relative without-label">
                        
                        <select name="location_id" id ="city_id" class="form-control location">
                          <option value="">Select</option>
                          <?php $__currentLoopData = $city_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('location_id') ? old('location_id') : $_GET['location_id'] ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-chevron-compact-down"></i>
                      </div>
                      <div class="form-group range">
                        <label for="">Price Range</label>
                        <?php 
                        $min = 0;
                        $max = $maxPrice;
                        if (isset($_GET['min']) && !empty($_GET['min'])) {
                          $min = $_GET['min'];
                        }
                        if (isset($_GET['max']) && !empty($_GET['max'])) {
                          $max = $_GET['max'];
                        }
                        ?>
                        <div>
                          <span class="minVal">$<?php echo e($min); ?></span>
                          <span class="maxVal">$<?php echo e($max); ?></span>
                        </div>
                          <input id="ex2" type="text" class="span2" value="" data-slider-min="0" data-slider-max="<?php echo e($maxPrice); ?>" data-slider-step="5" data-slider-value="[<?php echo e($min); ?>,<?php echo e($max); ?>]"/>
                        <div>
                          <span>min</span>
                          <span>max</span>
                        </div>
                      </div>
                      
                      <label for="">Period</label>
                      <div class="check-section">

                        <?php
                        $period = [
                                'spring'    => 'Spring',
                                'summer'    => 'Summer',
                                'fall'      => 'Fall',
                                'winter'    => 'Winter'
                            ];
                        $myArray = array();
                        if (isset($_GET['period'])) {
                          $myArray = explode(',', $_GET['period']);
                        }
                        
                        ?>
                        <?php foreach ($period as $id => $value): ?>
                          <div>
                            <label class="box"><?php echo e($value); ?>

                              <input name="period" type="checkbox" value="<?php echo e($id); ?>" <?php echo e((in_array($id, $myArray)) ? 'checked="checked"' : ''); ?> >
                              <span class="checkmark"></span>
                            </label>
                          </div>
                        <?php endforeach ?>
                        
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Starting age <span class="input-required">*</span></label>
                        <select class="form-control location" id="starting_age" name="starting_age">
                          <option value="">Select</option>
                          <?php 
                          for($value = 1; $value <= 20; $value++){ 
                            ?>
                              <option value="<?php echo e($value); ?>" <?php echo e((old('starting_age') ? old('starting_age') : $_GET['starting_age'] ?? '') == $value ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            <?php
                          }
                          ?>
                        </select>
                        <i class="bi bi-chevron-compact-down"></i>
                      </div>
                      <div class="form-group position-relative">
                        <label for="name">Rink <span class="input-required">*</span></label>
                        <select class="form-control location" id="rinks" name="rink_id" multiple="multiple">
                          <?php $__currentLoopData = $rink_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php $__currentLoopData = $filtered_rink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aItemKey => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($id == $p): ?>selected="selected"<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($value); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <i class="bi bi-plus-lg"></i>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-md-8">
              <div class="row">
              <div class="col-sm-12">
                <div class="card card-has-bg click-col">   

                    <?php if(isset($data['programs'])): ?>
                      <?php $__currentLoopData = $data['programs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card-body">
                          <div class="row">
                            <div class="col-md-3">
                              <?php if(isset($program['program_photo'][0])){ ?>
                                <img src="<?php echo e($BASE_URL); ?>/<?php echo e($program['program_photo'][0]['path']); ?>" alt="">
                              <?php } else{ ?>
                                <img src="<?php echo e(asset('img/default-thumbnail.jpeg')); ?>" alt="">
                              <?php } ?> 
                            </div>

                            
                            <div class="col-md-6">
                              <h3><?php echo e($program['name']); ?></h3>
                              <?php 
                              if(isset($program['program_period'])) {
                                
                                if(count($program['program_period']) >1) {
                                  $i=0;
                                  ?>
                                  <h6>
                                    <?php $__currentLoopData = $program['program_period']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                      <?php
                                        $period['start_date'] = date('F', strtotime($period['start_date']));
                                        $period['end_date'] = date('F', strtotime($period['end_date']));
                                      ?>
                                      <?php echo e(ucwords(strtolower($period['type']))); ?> (<?php echo e($period['start_date']); ?> - <?php echo e($period['end_date']); ?>)

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </h6> 
                                  <?php
                                }
                                else {

                                  //$today = new DateTime();
                                  $today      = strtotime('today');
                                  $date_year = date('Y', $today);

                                  $start_date      = strtotime($program['program_period'][0]['start_date']);
                                  $start_year = date('Y', $start_date);
                                  if ($date_year == $start_year) {
                                    $start_date = date('F d', $start_date);
                                  } else {
                                    $start_date = date('F d, Y', $start_date);
                                  }
                                  

                                  $end_date      = strtotime($program['program_period'][0]['end_date']);
                                  $end_year = date('Y', $end_date);
                                  if ($date_year == $end_year) {
                                    $end_date = date('F d', $end_date);
                                  } else {
                                    $end_date = date('F d, Y', $end_date);
                                  }
                                  ?>
                                  <h6><?php echo e($start_date); ?>-<?php echo e($end_date); ?></h6>
                                  <?php
                                }
                              }
                              ?>
                              <?php if(isset($program['rink'])): ?>
                                <h5><i class="fas fa-map-marker-alt"></i>
                                  
                                    <?php echo e($program['rink']['address']); ?>

                                  
                                </h5>
                              <?php endif; ?>
                              <h5><i class="fas fa-clock"></i>Starting at <?php echo e($program['starting_age']); ?></h5>
                              <h5><i class="fas fa-road"></i><?php echo e($program['level_name']); ?></h5>
                            </div> 
                            <div class="col-md-3 learn-more">
                              <a href="<?php echo e(!empty($program['id']) ? route('program-details', ['program' => $program['id']]): ''); ?>" class="btn btn-custom mb-2 green">Learn more</a>
                            </div>
                            
                          </div>
                        </div>
                       
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>        
                    
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
    </div>

    <script type="text/javascript">

      $(document).ready(function () {
        $('#rinks').multiselect();
    
        $("#ex2").bootstrapSlider({});
        // add logic change value of result top condition
        $('#province_id').on('change', function(){
            var name = $(this).attr('name');
            $('#city_id').html('');
            if (name == '') {
                return false;
            }

            var value = $(this).val();
            var csrfToken = $('meta[name="_token"]').attr('content') ? $('meta[name="_token"]').attr('content') : '';
          

            var data = {
                province_id: value,
                _token:csrfToken
            };


            $.ajax({
              type: 'POST',
              url: baseUrl + '/ajax_citylist',
              data: data,
              //dataType: 'json',
              success: function (response) {
                console.log(response);
                if (response) {
                    $('#city_id').html(response);
                } else {
                    $('#city_id').html('');
                }
              },
              complete: function () {}
            });
            return false;
        });
        $('.openTab').on('click',function (e) {
          e.preventDefault();
          $('.filter').show();

        })
        $('h1 i').on('click',function(e) {
          e.preventDefault();
          $('.filter').hide();
        })
      });
    </script>
    
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aburayhan/coach.abu-rayhan.me/framework/resources/views/pages/program/list.blade.php ENDPATH**/ ?>