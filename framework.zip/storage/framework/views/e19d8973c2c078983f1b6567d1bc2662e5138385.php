<?php echo e($slot); ?>

<?php /**PATH /home/ziih7ldwv5wz/public_html/framework/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>