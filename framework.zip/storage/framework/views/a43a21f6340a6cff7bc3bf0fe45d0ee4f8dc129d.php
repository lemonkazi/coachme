<?php echo e($slot); ?>

<?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>