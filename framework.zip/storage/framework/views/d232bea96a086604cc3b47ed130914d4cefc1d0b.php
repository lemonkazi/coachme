<?php $__env->startSection('title',$data['Title']); ?>
<?php $__env->startSection('content'); ?>
    <div class="coach-details">
        <div class="container">
          <div class="row">
            <div class="col-md-5">
              <h2><?php echo e($data['user']->name); ?> <?php echo e($data['user']->family_name); ?> <i class="fas fa-share-alt"></i></h2>
              <div class="row">
                <div class="col-md-6">
                  <label for="">Experience</label>
                  <p><?php echo e($data['user']->experience_name); ?></p>
                </div>
                <div class="col-md-6">
                  <label for="">Coaching certificate</label>
                  <p><?php echo e($data['user']->certificate_name); ?></p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <label for="">Speciality</label>
                  <p><?php echo e($data['speciality']); ?></p>
                </div>
                <div class="col-md-6">
                  <label for="">Language spoken</label>
                  <p><?php echo e($data['language']); ?></p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <label for="">Price</label>
                  <p>
                    <?php echo e($data['user']->price_name); ?>$
                  </p>
                </div>
                <div class="col-md-6">
                  <label for="">Rink</label>
                  <p>
                    <?php echo e($data['rink']); ?>

                  </p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label for="">Location</label>
                  <p><?php echo e($data['user']->city_name); ?></p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label for="">About me</label>
                  <p>
                    <?php echo e($data['user']->about); ?>

                  </p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label for="">Contact</label>
                  <h5><i class="bi bi-telephone-fill"></i>+<?php echo e($data['user']->phone_number); ?></h5>
                  <h5><i class="fas fa-at"></i><?php echo e($data['user']->email); ?></h5>
                  <h5><i class="fab fa-linkedin"></i>+<?php echo e($data['user']->whatsapp); ?></h5>
                </div>
              </div>
            </div>
            <div class="offset-md-3 col-md-4 ">
              <img src="<?php echo e($BASE_URL); ?>/photo/user_photo/<?php echo e($data['user']->avatar_image_path); ?>" />
            </div>
          </div>

        </div>
    </div>

    <script type="text/javascript">

      $(document).ready(function () {

        // add logic change value of result top condition
        $('#province_id').on('change', function(){
            var name = $(this).attr('name');
            $('#city_id').html('');
            if (name == '') {
                return false;
            }

            var value = $(this).val();
            var csrfToken = $('meta[name="_token"]').attr('content') ? $('meta[name="_token"]').attr('content') : '';
          

            var data = {
                province_id: value,
                _token:csrfToken
            };


            $.ajax({
              type: 'POST',
              url: baseUrl + '/ajax_citylist',
              data: data,
              //dataType: 'json',
              success: function (response) {
                console.log(response);
                if (response) {
                    $('#city_id').html(response);
                } else {
                    $('#city_id').html('');
                }
              },
              complete: function () {}
            });
            return false;
        });
      });
    </script>
    
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/resources/views/pages/coach/details.blade.php ENDPATH**/ ?>