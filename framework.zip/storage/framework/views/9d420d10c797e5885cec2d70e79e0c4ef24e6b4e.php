<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0"><?php echo e($data['Title']); ?></h1>
        </div><!-- /.col -->
        <?php
          echo htmlspecialchars_decode(render2($data['breadcrumb']))
        ?>

        <!--  <?php
             echo "<pre>";
               print_r($data['user']);
             echo "</pre>";
            ?> -->
        
        <?php echo e(session('msg')); ?>

      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- content HEADER -->
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
              <!-- general form elements -->
              <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title"><?php echo e($data['Title']); ?></h3>
                </div>

                <div class="card-body">
                  <?php if($errors->any()): ?>
                      <div class="alert alert-danger">
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
                  <?php endif; ?>
                  <!-- form start -->
                  <form action="<?php echo e(!empty($data['user']) ? route('coach.update',[$data['user']->id]): route('coach.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="name">Name <span class="input-required">*</span></label>
                          <input type="text" class="form-control" id="name" name="name" placeholder="Full Name"  value="<?php echo e(!empty($data['user']) ? old('name', $data['user']->name) : old('name')); ?>" required>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="family_name">Family Name</label>
                          <input type="text" class="form-control" id="family_name" name="family_name" placeholder="Family Name"  value="<?php echo e(!empty($data['user']) ? old('family_name', $data['user']->family_name) : old('family_name')); ?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="email">Email address <span class="input-required">*</span></label>
                          <input type="email" class="form-control" id="email" name="email" placeholder="Email"  value="<?php echo e(!empty($data['user']) ? old('email', $data['user']->email) : old('email')); ?>" required>
                        </div>
                      </div>
                      <div class="col-md-6">
                          <div class="form-group">
                              
                              <?php
                              if(!empty($data['user'])) {
                                ?>
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password"  value="<?php echo e(old('password')); ?>">
                                <?php
                              } else {
                                ?>
                                <label for="password">Password <span class="input-required">*</span></label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password"  value="<?php echo e(old('password')); ?>" required>
                                <?php
                              } 
                              ?>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="about">About</label>
                          <textarea class="form-control" id="about" name ="about" placeholder="about"><?php echo e(!empty($data['user']) ? old('about', $data['user']->about) : old('about')); ?></textarea>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="province">Province</label>
                          <select name="province_id" class="form-control" style="width: 100%">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $province_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('province_id') ? old('province_id') : $data['user']->province_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-6">
                          <div class="form-group">
                            <label for="city">City</label>
                            <select name="city_id" class="form-control" style="width: 100%">
                              <option value="">Select</option>
                              <?php $__currentLoopData = $city_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('city_id') ? old('city_id') : $data['user']->city_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="speciality">speciality</label>
                          <select name="speciality_id" class="form-control" style="width: 100%">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $speciality_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('speciality_id') ? old('speciality_id') : $data['user']->userinfos['speciality'][0]->content_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-6">
                          <div class="form-group">
                            <label for="experience">experience</label>
                            <select name="experience_id" class="form-control" style="width: 100%">
                              <option value="">Select</option>
                              <?php $__currentLoopData = $experience_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('experience_id') ? old('experience_id') : $data['user']->experience_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="rink">rink</label>
                          <select name="rink_id" class="form-control" style="width: 100%">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $rink_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('rink_id') ? old('rink_id') : $data['user']->rink_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-6">
                          <div class="form-group">
                            <label for="certificate">certificate</label>
                            <select name="certificate_id" class="form-control" style="width: 100%">
                              <option value="">Select</option>
                              <?php $__currentLoopData = $certificate_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('experience_id') ? old('experience_id') : $data['user']->experience_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="language">language</label>
                          <select name="language_id" class="form-control" style="width: 100%">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $language_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($id); ?>" <?php echo e((old('language_id') ? old('language_id') : $data['user']->language_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-6">
                          <div class="form-group">
                            <label for="price">price</label>
                            <select name="price_id" class="form-control" style="width: 100%">
                              <option value="">Select</option>
                              <?php $__currentLoopData = $price_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('price_id') ? old('price_id') : $data['user']->price_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="phone_number">Phone Number <span class="input-required">*</span></label>
                          <input type="text" class="form-control" id="phone_number" name="phone_number" placeholder="phone_number" value="<?php echo e(!empty($data['user']) ? old('phone_number', $data['user']->phone_number) : old('phone_number')); ?>" required>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="whatsapp">whatsapp</label>
                          <input type="text" class="form-control" id="whatsapp" name="whatsapp" value="<?php echo e(!empty($data['user']) ? old('whatsapp', $data['user']->whatsapp) : old('whatsapp')); ?>"  placeholder="whatsapp">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                            <label for="file">Upload Image</label>
                            <input type="file" name="avatar_image_path" id="file" placeholder="no file selected">
                        </div>
                      </div>
                    </div>
                      
                      <!-- /.card-body -->

                      <div class="card-footer">
                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                      </div>
                  </form>
                </div>  
              </div>
            </div>
            <div class="col-md-4">
              <div class="card card-secondary">
                <div class="card-header">
                  <h3 class="card-title">
                    Instraction
                  </h3>
                </div>
                <div class="card-body">
                  <ul>
                    <li><b>User name</b> 1 to 60 character.</li>
                    <li><b>email</b> place email here.</li>
                    <li><b>Password</b> Half-width alphanumeric characters between 8 and 20 characters.</li>
                  </ul>
                </div>
              </div>
            </div>
        </div>
    </div>
  </section>
  <!-- /.content -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/resources/views/admin/coach/add.blade.php ENDPATH**/ ?>