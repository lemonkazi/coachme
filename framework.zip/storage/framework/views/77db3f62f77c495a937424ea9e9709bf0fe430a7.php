<?php $__env->startSection('content'); ?>
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-user-secret" aria-hidden="true"></i>
                 </li>
                <li><a>Staff Profile</a></li>
            </ul>
        </div>
    </div>

    <div class="row">
      <div class="col-md-6 col-lg-4">
          <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
          <!--PROFILE-->
          <div>
              <div class="profile-photo">
                  <img alt="User photo" src="/user_photo/<?php echo e($user->image); ?>" />
              </div>
              <div class="user-header-info">
                  <h4 class="user-name"><?php echo e($user->name); ?></h4>
                  <h5 class="user-position"><?php echo e($user->authority); ?></h5>
                  <div class="user-social-media">
                      <span class="text-lg"><a href="#" class="fa fa-twitter-square"></a> <a href="#" class="fa fa-facebook-square"></a> <a href="#" class="fa fa-linkedin-square"></a> <a href="#" class="fa fa-google-plus-square"></a></span>
                  </div>
              </div>
          </div>
          <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
          <!--CONTACT INFO-->
          <div class="panel bg-scale-0 b-primary bt-sm mt-xl">
              <div class="panel-content">
                  <h4 class=""><b>Contact Information</b></h4>
                  <ul class="user-contact-info ph-sm">
                      <li><b><i class="color-primary mr-sm fa fa-envelope"></i></b> <?php echo e($user->email); ?></li>
                      <li><b><i class="color-primary mr-sm fa fa-phone"></i></b> </li>
                      <li><b><i class="color-primary mr-sm fa fa-globe"></i></b> </li>
                  </ul>
              </div>
          </div>
          <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
          <!--LIST-->
          <div class="panel  b-primary bt-sm ">
              <div class="panel-content">
                  <div class="widget-list list-sm list-left-element ">
                      <ul>
                          <li>
                              <a href="#">
                                  <div class="left-element"><i class="fa fa-check color-success"></i></div>
                                  <div class="text">
                                      <span class="title">95 Jobs</span>
                                      <span class="subtitle">Completed</span>
                                  </div>
                              </a>
                          </li>
                          <li>
                              <a href="#">
                                  <div class="left-element"><i class="fa fa-clock-o color-warning"></i></div>
                                  <div class="text">
                                      <span class="title">3 Proyects</span>
                                      <span class="subtitle">working on</span>
                                  </div>
                              </a>
                          </li>
                          <li>
                              <a href="#">
                                  <div class="left-element"><i class="fa fa-envelope color-primary"></i></div>
                                  <div class="text">
                                      <span class="title">Leave a Menssage</span>
                                  </div>
                              </a>
                          </li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
      <div class="col-md-6 col-lg-8">
          <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
          <!--TIMELINE-->
          <div class="timeline animated fadeInUp">
              <div class="timeline-box">
                  <div class="timeline-icon bg-primary">
                      <i class="fa fa-phone"></i>
                  </div>
                  <div class="timeline-content">
                      <h4 class="tl-title">Ello impedit iusto</h4> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur distinctio illo impedit iusto minima nisi quo tempora ut!
                  </div>
                  <div class="timeline-footer">
                      <span>Today. 14:25</span>
                  </div>
              </div>
              <div class="timeline-box">
                  <div class="timeline-icon bg-primary">
                      <i class="fa fa-tasks"></i>
                  </div>
                  <div class="timeline-content">
                      <h4 class="tl-title">consectetur adipisicing </h4> Lorem ipsum dolor sit amet. Consequatur distinctio illo impedit iusto minima nisi quo tempora ut!
                  </div>
                  <div class="timeline-footer">
                      <span>Today. 10:55</span>
                  </div>
              </div>
              <div class="timeline-box">
                  <div class="timeline-icon bg-primary">
                      <i class="fa fa-file"></i>
                  </div>
                  <div class="timeline-content">
                      <h4 class="tl-title">Impedit iusto minima nisi</h4> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur distinctio illo impedit iusto minima nisi quo tempora ut!
                  </div>
                  <div class="timeline-footer">
                      <span>Today. 9:20</span>
                  </div>
              </div>
              <div class="timeline-box">
                  <div class="timeline-icon bg-primary">
                      <i class="fa fa-check"></i>
                  </div>
                  <div class="timeline-content">
                      <h4 class="tl-title">Lorem ipsum dolor sit</h4> Lorem ipsum dolor sit amet Consequatur distinctio illo impedit iusto minima nisi quo tempora ut!
                  </div>
                  <div class="timeline-footer">
                      <span>Yesteday. 16:30</span>
                  </div>
              </div>
          </div>
          <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
          <!--GALLERY-->
      </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/user/new_volume/xampp/htdocs/coachme/resources/views/coach/detail.blade.php ENDPATH**/ ?>